IMCL 2026, submission 1199 (camera-ready LaTeX source)
Work-in-Progress: From Generic Chatbots to Teacher-Configurable AI Tutors -
The Design and Evaluation of Novedu in Secondary Education

Files
  novedu-wip.tex        main source (Springer LNCS class, llncs.cls v2.24)
  references.bib        bibliography (BibTeX)
  novedu-wip.bbl        pre-generated bibliography (splncs04 style)
  llncs.cls             Springer LNCS document class (from the conference kit)
  splncs04.bst          Springer LNCS BibTeX style (from the conference kit)
  aliascnt.sty, remreset.sty  packages required by llncs.cls
  figures/NoveduApproachesComparison.pdf  Figure 1 (vector PDF)
  figures/NoveduApproachesComparison.svg  Figure 1 source (SVG)

Build (pdfLaTeX)
  pdflatex novedu-wip
  bibtex   novedu-wip
  pdflatex novedu-wip
  pdflatex novedu-wip
